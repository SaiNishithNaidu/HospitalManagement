package com.spring.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.spring.web.entities.User;
import com.spring.web.repository.UserRepository;

@Controller
public class AppController {
	
	@Autowired
	private UserRepository repo;

	@GetMapping("/index")
	public String viewHomePage() {
		System.out.println("This is Home page!");
		return "index";
	}
	@GetMapping("/register")
	public String registerUser(Model model) {
		model.addAttribute("user",new User());
		System.out.println("Welcome to registration Page");
		return "signup_form";
	}
	@PostMapping("/process_register")
	public String processRegistration(User user) {
		System.out.println("You are Successfully Registered!");
		repo.save(user);
		return "register_success";
	}
}
